
-- ================================================
-- SCRIPT DE CREACIÓN DE ESQUEMA STAGING Y CARGA DE DATOS
-- Proyecto: DataMart Jardinería
-- ================================================

USE DataMartJardineria;
GO

-- 1. Crear esquema Staging (si no existe)
IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = 'Staging')
BEGIN
    EXEC('CREATE SCHEMA Staging');
END;
GO

-- 2. CREACIÓN DE TABLAS EN STAGING

-- Cliente
IF OBJECT_ID('Staging.Cliente') IS NOT NULL DROP TABLE Staging.Cliente;
CREATE TABLE Staging.Cliente (
    idCliente INT,
    nombreCliente NVARCHAR(100),
    pais NVARCHAR(50),
    telefono NVARCHAR(50)
);

-- Producto
IF OBJECT_ID('Staging.Producto') IS NOT NULL DROP TABLE Staging.Producto;
CREATE TABLE Staging.Producto (
    idProducto INT,
    nombre NVARCHAR(100),
    gama NVARCHAR(50),
    proveedor NVARCHAR(100)
);

-- Pedido
IF OBJECT_ID('Staging.Pedido') IS NOT NULL DROP TABLE Staging.Pedido;
CREATE TABLE Staging.Pedido (
    idPedido INT,
    idCliente INT,
    fechaPedido DATE,
    fechaEntrega DATE,
    idEmpleado INT
);

-- DetallePedido
IF OBJECT_ID('Staging.DetallePedido') IS NOT NULL DROP TABLE Staging.DetallePedido;
CREATE TABLE Staging.DetallePedido (
    idPedido INT,
    idProducto INT,
    cantidad INT,
    precioUnitario DECIMAL(10,2)
);

-- Oficina
IF OBJECT_ID('Staging.Oficina') IS NOT NULL DROP TABLE Staging.Oficina;
CREATE TABLE Staging.Oficina (
    idOficina NVARCHAR(10),
    ciudad NVARCHAR(100),
    pais NVARCHAR(50)
);

-- Empleado
IF OBJECT_ID('Staging.Empleado') IS NOT NULL DROP TABLE Staging.Empleado;
CREATE TABLE Staging.Empleado (
    idEmpleado INT,
    nombre NVARCHAR(100),
    apellido NVARCHAR(100),
    puesto NVARCHAR(100),
    idOficina NVARCHAR(10)
);

-- 3. CARGA DE DATOS DESDE JARDINERIA.DBO HACIA STAGING

-- Clientes
INSERT INTO Staging.Cliente (idCliente, nombreCliente, pais, telefono)
SELECT codigo_cliente, nombre_cliente, pais, telefono
FROM Jardineria.dbo.Cliente;

-- Productos
INSERT INTO Staging.Producto (idProducto, nombre, gama, proveedor)
SELECT codigo_producto, nombre, gama, proveedor
FROM Jardineria.dbo.Producto;

-- Pedidos
INSERT INTO Staging.Pedido (idPedido, idCliente, fechaPedido, fechaEntrega, idEmpleado)
SELECT codigo_pedido, codigo_cliente, fecha_pedido, fecha_entrega, codigo_empleado_rep_ventas
FROM Jardineria.dbo.Pedido;

-- Detalle de Pedidos
INSERT INTO Staging.DetallePedido (idPedido, idProducto, cantidad, precioUnitario)
SELECT codigo_pedido, codigo_producto, cantidad, precio_unidad
FROM Jardineria.dbo.DetallePedido;

-- Oficinas
INSERT INTO Staging.Oficina (idOficina, ciudad, pais)
SELECT codigo_oficina, ciudad, pais
FROM Jardineria.dbo.Oficina;

-- Empleados
INSERT INTO Staging.Empleado (idEmpleado, nombre, apellido, puesto, idOficina)
SELECT codigo_empleado, nombre, apellido1, puesto, codigo_oficina
FROM Jardineria.dbo.Empleado;

-- ================================================
-- FIN DEL SCRIPT DE STAGING Y CARGA DE DATOS
-- ================================================
